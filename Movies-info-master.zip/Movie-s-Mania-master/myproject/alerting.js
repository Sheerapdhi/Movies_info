/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function myfun()
{
alert("Enter movie name");
if(alert("Enter movie")) document.location = 'C:\\Users\\USER\\Documents\\NetBeansProjects\\myproject\\web\\index.html';                       
}